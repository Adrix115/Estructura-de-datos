// ProgArch.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
//

#include <iostream>
#include <fstream>
#include "ABMamigo.h"

using namespace std;


void main() {
	ABMamigo* amig = new ABMamigo("amigOO.dat");
	amig->adicionarNuevo();
	//amig->buscarReg();
	//amig->eliminarReg();
	//amig->modificarReg();
	cout << "Listado" << endl;
	amig->listar();
	
}